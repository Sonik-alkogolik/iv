$('.js-open-modal').click(function(event){
    event.preventDefault();
  let modalname = $(this).attr('data-modal');
  let modal = $('.js-modal[data-modal="'+ modalname +'"]');
  let ovarlay = $('.overlay');
  ovarlay.addClass('modal-show');
   modal.addClass('modal-show');
   $('body').css('overflow', 'hidden');
   $('.modal-close').click(function(event){
    event.preventDefault();
    let modal = $('.js-modal[data-modal="'+ modalname +'"]');
    modal.removeClass('modal-show');
    ovarlay.removeClass('modal-show');
    $('body').css('overflow', 'scroll');
});
});
