const gulp = require('gulp');
const del = require('del');
const gulppug = require('gulp-pug');
const sass = require('gulp-sass')(require('sass'));
const pref = require('gulp-autoprefixer');
const babel = require('gulp-babel');
const browserSync = require('browser-sync').create();


 function clean() {
  return del ('dist');
 }



function pug2html(){
    return gulp.src('dev/pug/*.pug')
    .pipe(gulppug({
        pretty:true
    }))
    .pipe(gulp.dest('dist'));
}
function scssstyle(){
    return gulp.src('dev/style/*.scss')
    .pipe(sass())
    .pipe(pref())
    .pipe(browserSync.stream())
    .pipe(gulp.dest('dist'))
}
function script(){
    return gulp.src('dev/js/**/*.js')
    .pipe(babel({
        presets: ['@babel/env']
    }))
    .pipe(gulp.dest('dist'));
}



function watch() {
    browserSync.init({
        server: {
            baseDir: "dist"
        }
    });
     gulp.watch(["dev/pug/**/*.pug","dev/style/**/*.scss"], gulp.series(pug2html,scssstyle));
     gulp.watch("dist/*.css").on('change', browserSync.reload);
    gulp.watch("dist/*.html").on('change', browserSync.reload);
}


exports.default = gulp.series(clean,
pug2html,scssstyle,script,watch);
